#define CONTENTS "recover_contents.rec"



typedef struct recovery_meta_type{
    int writing;
    int entries;
} recovery_meta;
